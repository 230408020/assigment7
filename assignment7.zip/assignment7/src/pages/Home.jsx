import { Link } from "react-router";

export default function Home() {
  return (
    <section>
      <h1>Welcome to Mini Shop</h1>
      <p>Browse the catalogue, filter it, share the filtered view by link and fill your cart.</p>
      <p>
        <Link to="/products" className="button-link">
          Browse products
        </Link>
      </p>
      <p className="muted">Sign in to see your cart.</p>
    </section>
  );
}
