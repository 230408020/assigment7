import { useSearchParams } from "react-router";
import { useFetch } from "../hooks/useFetch.js";
import { fetchProducts } from "../api/productsApi.js";
import ProductCard from "../components/ProductCard.jsx";

export default function ProductList() {
  const { loading, error, data: products } = useFetch((signal) => fetchProducts(signal), []);
  const [searchParams, setSearchParams] = useSearchParams();

  // The URL is the single source of truth for the filters.
  const query = searchParams.get("q") ?? "";
  const category = searchParams.get("category") ?? "";

  // Update ONE parameter while keeping the others.
  function updateParam(name, value) {
    setSearchParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        if (value) next.set(name, value);
        else next.delete(name);
        return next;
      },
      { replace: true }
    );
  }

  if (loading) return <p className="status">Loading products…</p>;
  if (error) return <p className="status error">Could not load products: {error.message}</p>;

  // Derived during render: not stored in state, not computed in an effect.
  const categories = [...new Set(products.map((p) => p.category))].sort();
  const normalizedQuery = query.trim().toLowerCase();
  const visibleProducts = products.filter(
    (p) =>
      (category === "" || p.category === category) &&
      p.title.toLowerCase().includes(normalizedQuery)
  );

  return (
    <section>
      <h1>Products</h1>

      <div className="filters">
        <input
          type="search"
          placeholder="Search by title…"
          value={query}
          onChange={(e) => updateParam("q", e.target.value)}
        />
        <select value={category} onChange={(e) => updateParam("category", e.target.value)}>
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        {(query || category) && (
          <button type="button" onClick={() => setSearchParams({}, { replace: true })}>
            Reset filters
          </button>
        )}
      </div>

      <p className="muted">
        Showing {visibleProducts.length} of {products.length} products
      </p>

      {visibleProducts.length === 0 ? (
        <p className="status">No products match your filters.</p>
      ) : (
        <div className="grid">
          {visibleProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </section>
  );
}
