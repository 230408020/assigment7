import { Link, useNavigate, useParams } from "react-router";
import { useFetch } from "../hooks/useFetch.js";
import { fetchProduct } from "../api/productsApi.js";
import { useCartStore } from "../store/cartStore.js";

export default function ProductDetail() {
  // Route params are always strings, e.g. "3", not 3.
  const { id } = useParams();
  const numericId = Number(id);
  const navigate = useNavigate();
  const addItem = useCartStore((state) => state.addItem);

  // id is a dependency: going from /products/3 to /products/4 refetches
  // and the previous request is aborted.
  const { loading, error, data: product } = useFetch((signal) => fetchProduct(id, signal), [id]);

  const backButton = (
    <button type="button" onClick={() => navigate("/products")}>
      ← Back to products
    </button>
  );

  if (loading) return <p className="status">Loading product…</p>;

  if (error) {
    return (
      <section>
        {backButton}
        <p className="status error">
          {error.status === 404 || error.status === 400
            ? `Product not found (id "${id}").`
            : `Could not load product: ${error.message}`}
        </p>
      </section>
    );
  }

  return (
    <section className="detail">
      {backButton}
      <div className="detail-body">
        <img src={product.thumbnail} alt={product.title} />
        <div>
          <h1>{product.title}</h1>
          <p className="muted">{product.category}</p>
          <p>{product.description}</p>
          <p className="price">${product.price.toFixed(2)}</p>
          <button type="button" onClick={() => addItem(product)}>
            Add to cart
          </button>
        </div>
      </div>
      <nav className="pager">
        {numericId > 1 && <Link to={`/products/${numericId - 1}`}>← Previous product</Link>}
        <Link to={`/products/${numericId + 1}`}>Next product →</Link>
      </nav>
    </section>
  );
}
