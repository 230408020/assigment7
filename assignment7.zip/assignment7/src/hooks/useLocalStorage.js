import { useEffect, useState } from "react";

function readValue(key, initialValue) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw === null ? initialValue : JSON.parse(raw);
  } catch {
    // Missing, corrupted JSON or storage blocked -> fall back to the default.
    return initialValue;
  }
}

/** Same call shape as useState, but the value is persisted in localStorage. */
export function useLocalStorage(key, initialValue) {
  // Lazy initialiser: localStorage is read only on the first render.
  const [value, setValue] = useState(() => readValue(key, initialValue));

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Storage full or unavailable: the app still works, it just won't remember.
    }
  }, [key, value]);

  return [value, setValue];
}
