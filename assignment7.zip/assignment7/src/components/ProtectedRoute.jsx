import { Navigate, useLocation } from "react-router";
import { useAuth } from "../context/AuthContext.jsx";

// UX only, NOT security: the code and data are still in the browser.
export default function ProtectedRoute({ children }) {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) {
    // Remember where the user wanted to go; replace so /cart is not left in history.
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return children;
}
