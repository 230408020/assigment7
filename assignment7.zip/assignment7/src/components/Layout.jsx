import { Outlet } from "react-router";
import NavBar from "./NavBar.jsx";
import { useLocalStorage } from "../hooks/useLocalStorage.js";

export default function Layout() {
  const [theme, setTheme] = useLocalStorage("theme", "light");
  const isDark = theme === "dark";

  function toggleTheme() {
    setTheme((current) => (current === "dark" ? "light" : "dark"));
  }

  return (
    <div className={`app theme-${isDark ? "dark" : "light"}`}>
      <NavBar theme={isDark ? "dark" : "light"} onToggleTheme={toggleTheme} />
      <main className="content">
        {/* The matched child route renders here */}
        <Outlet />
      </main>
      <footer className="footer">
        <p>Mini Shop · Web Programming Assignment 7 · Data from DummyJSON</p>
      </footer>
    </div>
  );
}
