import { NavLink, useNavigate } from "react-router";
import { useAuth } from "../context/AuthContext.jsx";
import { useCartStore, selectItemCount } from "../store/cartStore.js";

function linkClass({ isActive }) {
  return isActive ? "nav-link active" : "nav-link";
}

export default function NavBar({ theme, onToggleTheme }) {
  const { user, logOut } = useAuth();
  // Selector returns a number (primitive), so NavBar re-renders only when the count changes.
  const itemCount = useCartStore(selectItemCount);
  const navigate = useNavigate();

  function handleLogout() {
    logOut();
    navigate("/", { replace: true });
  }

  return (
    <header className="navbar">
      <nav className="nav-links">
        <NavLink to="/" end className={linkClass}>
          Home
        </NavLink>
        <NavLink to="/products" className={linkClass}>
          Products
        </NavLink>
        <NavLink to="/cart" className={linkClass}>
          Cart <span className="badge">{itemCount}</span>
        </NavLink>
      </nav>

      <div className="nav-actions">
        <button type="button" onClick={onToggleTheme}>
          {theme === "dark" ? "☀ Light" : "☾ Dark"}
        </button>
        {user ? (
          <>
            <span className="username">{user.username}</span>
            <button type="button" onClick={handleLogout}>
              Logout
            </button>
          </>
        ) : (
          <NavLink to="/login" className={linkClass}>
            Login
          </NavLink>
        )}
      </div>
    </header>
  );
}
