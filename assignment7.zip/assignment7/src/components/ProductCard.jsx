import { Link } from "react-router";
import { useCartStore } from "../store/cartStore.js";

export default function ProductCard({ product }) {
  // Only the action is selected: adding items elsewhere does not re-render this card.
  const addItem = useCartStore((state) => state.addItem);

  return (
    <article className="card">
      <Link to={`/products/${product.id}`}>
        <img src={product.thumbnail} alt={product.title} loading="lazy" />
        <h3>{product.title}</h3>
      </Link>
      <p className="muted">{product.category}</p>
      <p className="price">${product.price.toFixed(2)}</p>
      <button type="button" onClick={() => addItem(product)}>
        Add to cart
      </button>
    </article>
  );
}
