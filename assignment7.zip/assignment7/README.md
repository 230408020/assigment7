# Assignment 7 – Mini Shop (React Router, Context, Zustand)

A small online shop built with React + Vite. It loads products from the public
[DummyJSON](https://dummyjson.com) API, lets visitors filter the catalogue (and share the
filtered view by link), shows a detail page per product, and has a cart that only
signed-in users can open. The cart and the light/dark theme are remembered between visits.

## Getting started

```bash
npm install
npm run dev      # development server
npm run build    # production build
```

**Demo account**

| Username | Password |
| --- | --- |
| `230408020@st.biruni.edu.tr` | `demo123456` |

## File organisation

```
src/
├─ api/
│  ├─ productsApi.js     fetchProducts / fetchProduct (fetch + AbortSignal, no React)
│  └─ authApi.js         fake login() that resolves after ~500 ms
├─ hooks/
│  ├─ useFetch.js        loading / error / data with useReducer + abort on cleanup
│  └─ useLocalStorage.js useState-like hook persisted in localStorage (theme)
├─ context/
│  └─ AuthContext.jsx    AuthProvider + useAuth (useReducer: LOGGED_IN / LOGGED_OUT)
├─ store/
│  └─ cartStore.js       Zustand cart store + localStorage persistence via subscribe
├─ components/
│  ├─ Layout.jsx         NavBar + <Outlet /> + footer, applies the theme class
│  ├─ NavBar.jsx         NavLinks, cart count, theme toggle, login / logout
│  ├─ ProductCard.jsx    one product in the grid
│  └─ ProtectedRoute.jsx redirects to /login and remembers the target page
├─ pages/
│  ├─ Home.jsx
│  ├─ ProductList.jsx    filters stored in the query string (?q=&category=)
│  ├─ ProductDetail.jsx  reads :id, previous/next links, "product not found"
│  ├─ Cart.jsx           quantity controls, total, clear, empty state
│  ├─ Login.jsx          controlled form, loading + error, redirect back
│  └─ NotFound.jsx       404 page inside the layout
├─ App.jsx               route table (nested /products routes)
├─ main.jsx              BrowserRouter + AuthProvider
└─ index.css             theme variables + minimal styling
```

### Routes

| Path | Page | Access |
| --- | --- | --- |
| `/` | Home | Public |
| `/products` | ProductList | Public |
| `/products/:id` | ProductDetail | Public |
| `/cart` | Cart | Signed-in users only |
| `/login` | Login | Public |
| `*` | NotFound | Public |

All routes are children of a layout route (`<Layout />`), so every page is rendered through
`<Outlet />` with the same navigation bar and footer. `ProductList` and `ProductDetail` are
nested under a `products` parent route.

## Reasoning questions

### State choices

- **Signed-in user:** in `AuthContext` (Context + `useReducer`). Many components (NavBar,
  ProtectedRoute, Login) need it, but it changes very rarely (login/logout), so Context's
  "re-render every consumer" behaviour costs almost nothing.
- **Cart:** in a Zustand store (`cartStore.js`). It changes often and is read in many places,
  and Zustand lets each component subscribe to only the slice it needs. It is saved to
  localStorage so it survives reloads.
- **Filter values:** in the URL query string (`?q=...&category=...`) via `useSearchParams`.
  This makes the filtered view shareable, bookmarkable and refresh-safe; the URL is the
  single source of truth, so there is no duplicate copy in `useState`.
- **Product list:** local state inside `ProductList`, managed by `useFetch`. It is server data
  that only this page needs, and the filtered list is derived from it during render.
- **Theme:** in `Layout` via `useLocalStorage`, so it is remembered between visits and is
  applied as a class on the wrapper element that contains the whole app.

### Context versus store

The user changes only when someone logs in or out, so re-rendering all Context consumers is
fine, and Context is built into React with no extra library. The cart changes on every click
of "Add to cart" or "+"; with Context, every consumer of the cart (NavBar, every ProductCard,
Cart) would re-render on each change because Context cannot subscribe to a part of its value.
With Zustand selectors, the NavBar re-renders only when the item count changes and the
ProductCards (which select only `addItem`) don't re-render at all. Putting the user in Zustand
would work but adds a global singleton for very rare updates and loses the "must be inside a
provider" check that `useAuth` gives us.

### Custom hooks

`useFetch` shares the *logic*: the loading/error/data reducer, starting a request when the
inputs change, ignoring aborted requests and aborting in the cleanup function. It deliberately
does **not** share *state*: each call creates its own `useReducer`, so `ProductList` and
`ProductDetail` each have independent loading/error/data. It also doesn't know which URL to
call; the component passes a fetcher function and the list of inputs it depends on.

### Route parameters

`useParams()` always returns strings, so `id` is `"3"`, not `3`. This mattered in two places in
`ProductDetail.jsx`: building the previous/next links (`"3" + 1` would be `"31"`, so I convert
with `Number(id)` first), and the cart, where items store the numeric `id` that comes from the
API response, not the string from the URL, so `item.id === product.id` compares numbers.
The string `id` is also the `useFetch` dependency, so changing the URL from `/products/3` to
`/products/4` aborts the old request and loads the new product.

### Protected routes

`ProtectedRoute` only decides what the browser *shows*. All JavaScript, including the Cart page,
is downloaded to the browser, and the "user" is just a value in memory that anyone can change
with DevTools. Real security must be enforced on a server: the server checks credentials,
issues a session or signed token (e.g. an HttpOnly cookie or JWT), and every API request for
private data (like a saved cart) is verified on the server before any data is returned.
So client-side protection is a user-experience feature, not security.

### Deep links

A plain static file server looks for a real file at `/products/3`; that file doesn't exist,
so it returns a 404 and the React app never loads. Routing only happens in the browser after
`index.html` and the JavaScript are loaded. The Vite dev server has an SPA "history API
fallback": for unknown paths it serves `index.html`, and React Router then reads the URL and
shows the right page. On a static host you need a rewrite rule that serves `index.html` for all
routes (e.g. Netlify `_redirects`, Vercel rewrites, or nginx `try_files $uri /index.html`).

## Self-study notes

- **Updating one query-string parameter without losing the others.** The React Router docs
  show that `setSearchParams` also accepts a function that receives the current params. In
  `ProductList.updateParam` I copy them with `new URLSearchParams(prev)`, then `set` or `delete`
  only the changed key, so changing the category keeps `q` and vice versa. Empty values are
  deleted to keep the URL clean, and `{ replace: true }` stops every keystroke from adding a
  history entry.
- **Initialising store state from localStorage safely.** `loadItems()` in `cartStore.js` wraps
  `JSON.parse` in `try/catch`, returns `[]` if the key is missing, the JSON is corrupted or the
  value is not an array, and filters out items with the wrong shape. Saving uses
  `useCartStore.subscribe((state, prev) => ...)` from the Zustand docs, outside React, and only
  writes when the `items` reference actually changed. `useLocalStorage` uses the same
  try/catch idea plus a lazy `useState` initialiser so localStorage is read only once.
- **Light/dark theme.** I used CSS custom properties: `.theme-light` and `.theme-dark` define
  the same variables (`--bg`, `--text`, `--surface`, ...) with different values, and all other
  CSS uses `var(...)`. `Layout` puts `theme-light` or `theme-dark` on the wrapper element, so
  toggling one class changes the whole app.
- **Zustand selectors.** From the Zustand docs: a selector that returns a new object/array on
  every call causes extra re-renders (or an infinite loop in v5). So every selector returns a
  primitive (`selectItemCount` returns a number) or an existing reference (`state.items`,
  `state.addItem`).

## Challenges

- Making `useFetch` reusable without breaking the Rules of Hooks: the caller passes the
  dependency list, and the hook handles `AbortError` so that a cancelled request (e.g. React
  StrictMode running the effect twice, or quickly clicking "Next product") never shows a fake
  error or overwrites newer data.
- `fetch` doesn't reject on 404, so `/products/999999` first looked like a successful request.
  I added an `response.ok` check in the API layer and a `status` field on the error so the
  detail page can show "Product not found".
- Sending the user back to the page they wanted after login, including the query string,
  without leaving `/login` in the history (`state.from` + `navigate(..., { replace: true })`).
- Keeping derived values (filtered products, categories, item count, total) out of state and
  computing them during render or in selectors instead.
